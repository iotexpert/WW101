readme.txt
ww101board.GBL	Gerber - Bottom copper
ww101board.GBO	Gerber - Bttom silkscreen
ww101board.GBS	Gerber - Bottom solder mask
ww101board.GKO	Gerber - Board outline
ww101board.GTL	Gerber - Top copper
ww101board.GTO	Gerber - Top silkscreen
ww101board.GTP	Gerber - Top paste
ww101board.GTS	Gerber - Top solder mask
ww101board.TXT	Excellon - drill file
ww101board.dri	Drill Station Info File in Text
ww101board.gpi	PhotoPlotter Info File in Text
